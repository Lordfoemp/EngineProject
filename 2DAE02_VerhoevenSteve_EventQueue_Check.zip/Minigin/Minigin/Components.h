#pragma once

#include "Component.h"
#include "FPSComponent.h"
#include "HealthComponent.h"
#include "LevelComponent.h"
#include "RenderComponent.h"
#include "ScoreComponent.h"
#include "TextComponent.h"
#include "TextComponent.h"
#include "TransformComponent.h"