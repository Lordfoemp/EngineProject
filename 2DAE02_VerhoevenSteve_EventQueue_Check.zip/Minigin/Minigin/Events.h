#pragma once
namespace Helheim
{
	enum class AudioMessages
	{
		PLAYER_DIED = 0,
		SCORE_UP = 1
	};
}

