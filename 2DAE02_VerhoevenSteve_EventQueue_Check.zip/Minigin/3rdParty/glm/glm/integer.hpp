/// @ref core
/// @file glm/integer.hpp

#pragma once

#include "detail/func_integer.hpp"
